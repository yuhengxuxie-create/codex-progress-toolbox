Artifact Delivery Sample
